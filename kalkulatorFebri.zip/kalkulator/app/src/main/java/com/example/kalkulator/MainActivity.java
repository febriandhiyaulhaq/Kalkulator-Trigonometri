package com.example.kalkulator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {



    private Button btn_sin, btn_cos, btn_tan, btn_cosec,btn_sec, btn_ctg,btnlog10;
    private TextView hasil;
    private EditText input;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_sin = findViewById(R.id.SIN);
        btn_cos = findViewById(R.id.COS);
        btn_tan = findViewById(R.id.TAN);
        btn_cosec = findViewById(R.id.COSEC);
        btn_sec = findViewById(R.id.SEC);
        btn_ctg = findViewById(R.id.CTG);
        hasil = findViewById(R.id.hasil);
        input = findViewById(R.id.input);
        btnlog10 =findViewById(R.id.log10);


        btn_sin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                String sInput = input.getText().toString();
                double INPUT = Double.parseDouble(sInput);

                double HASIL = Math.sin(INPUT);
                String sHasil = String.valueOf(HASIL);

                hasil.setText(sHasil);
                }catch(NumberFormatException nfe){
                    Toast.makeText(getApplicationContext(),"Field Tidak Boleh Kosong",Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_cos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String sInput = input.getText().toString();
                    double INPUT = Double.parseDouble(sInput);

                    double HASIL = Math.cos(INPUT);
                    String sHasil = String.valueOf(HASIL);

                    hasil.setText(sHasil);
                }catch(NumberFormatException nfe){
                    Toast.makeText(getApplicationContext(),"Field Tidak Boleh Kosong",Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_tan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                String sInput = input.getText().toString();
                double INPUT = Double.parseDouble(sInput);

                double HASIL = Math.tan(INPUT);
                String sHasil = String.valueOf(HASIL);

                hasil.setText(sHasil);
                }catch(NumberFormatException nfe){
                    Toast.makeText(getApplicationContext(),"Field Tidak Boleh Kosong",Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_cosec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                String sInput = input.getText().toString();
                double INPUT = Double.parseDouble(sInput);

                double HASIL = 1.0/Math.sin(INPUT);
                String sHasil = String.valueOf(HASIL);

                hasil.setText(sHasil);
                }catch(NumberFormatException nfe){
                    Toast.makeText(getApplicationContext(),"Field Tidak Boleh Kosong",Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_sec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                String sInput = input.getText().toString();
                double INPUT = Double.parseDouble(sInput);

                double HASIL = 1.0/Math.cos(INPUT);
                String sHasil = String.valueOf(HASIL);

                hasil.setText(sHasil);
                }catch(NumberFormatException nfe){
                    Toast.makeText(getApplicationContext(),"Field Tidak Boleh Kosong",Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_ctg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                String sInput = input.getText().toString();
                double INPUT = Double.parseDouble(sInput);

                double HASIL = 1.0/Math.tan(INPUT);
                String sHasil = String.valueOf(HASIL);

                hasil.setText(sHasil);
                }catch(NumberFormatException nfe){
                    Toast.makeText(getApplicationContext(),"Field Tidak Boleh Kosong",Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnlog10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                String sInput = input.getText().toString();
                double INPUT = Double.parseDouble(sInput);

                double HASIL = Math.log10(INPUT);
                String sHasil = String.valueOf(HASIL);

                hasil.setText(sHasil);
                }catch(NumberFormatException nfe){
                    Toast.makeText(getApplicationContext(),"Field Tidak Boleh Kosong",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
